import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RestApiClientService {

    @Value("${api.url}")
    private String apiUrl; // Inject API URL from configuration

    @Autowired
    private RestTemplate restTemplate;

    public void sendToApi(Customer customer) {
        // Set up HTTP headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Create an HttpEntity with the Customer object and headers
        HttpEntity<Customer> requestEntity = new HttpEntity<>(customer, headers);

        // Send the POST request and retrieve the response
        restTemplate.postForObject(apiUrl, requestEntity, String.class);
    }
}
