// CustomerService.java

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer getByCustomerRef(String customerRef) {
        return customerRepository.findByCustomerRef(customerRef);
    }

    public void saveAll(List<Customer> customers) {
        customerRepository.saveAll(customers);
    }
}
