import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service
public class CsvReaderService {

    public List<Customer> readCsvFile(InputStream inputStream) throws IOException, CsvValidationException {
        List<Customer> customers = new ArrayList<>();

        // Create CSVParser with custom separator and quote character if needed
        CSVParser csvParser = new CSVParserBuilder()
                .withSeparator(',')
                .withQuoteChar('"')
                .build();

        // Create CSVReader with the provided InputStream and CSVParser
        try (CSVReader csvReader = new CSVReaderBuilder(new InputStreamReader(inputStream))
                .withSkipLines(1) // Skip header line if present
                .withCSVParser(csvParser)
                .build()) {

            String[] nextRecord;
            while ((nextRecord = csvReader.readNext()) != null) {
                if (nextRecord.length == 8) {
                    Customer customer = new Customer();
                    customer.setCustomerRef(nextRecord[0]);
                    customer.setCustomerName(nextRecord[1]);
                    customer.setAddressLine1(nextRecord[2]);
                    customer.setAddressLine2(nextRecord[3]);
                    customer.setTown(nextRecord[4]);
                    customer.setCounty(nextRecord[5]);
                    customer.setCountry(nextRecord[6]);
                    customer.setPostcode(nextRecord[7]);

                    customers.add(customer);
                } else {
                    throw  new RuntimeException("Invalid row with incorrect number of columns");
                }
            }
        }

        return customers;
    }
}
