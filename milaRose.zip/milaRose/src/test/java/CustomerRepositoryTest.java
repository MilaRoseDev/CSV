import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class CustomerRepositoryTest {

    @Mock
    private JpaRepository<Customer, Long> jpaRepository;

    @InjectMocks
    private CustomerRepository customerRepository;

    @Test
    public void testFindByCustomerRef() {
        // Mocking dependencies
        String customerRef = "123";
        Customer expectedCustomer = new Customer();
        when(jpaRepository.findById(1L)).thenReturn(Optional.of(expectedCustomer));

        // Perform the test
        Customer result = customerRepository.findByCustomerRef(customerRef);

        // Assertions
        assertEquals(expectedCustomer, result);
        verify(jpaRepository, times(1)).findById(1L);
    }

    @Test
    public void testFindByCustomerRefNotFound() {
        // Mocking dependencies for a scenario where customer is not found
        String customerRef = "456";
        when(jpaRepository.findById(2L)).thenReturn(Optional.empty());

        // Perform the test
        Customer result = customerRepository.findByCustomerRef(customerRef);

        // Assertions
        assertEquals(null, result);
        verify(jpaRepository, times(1)).findById(2L);
    }
}
