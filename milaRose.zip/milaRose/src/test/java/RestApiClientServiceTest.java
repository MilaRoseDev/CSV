import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Mockito.*;

@SpringBootTest
public class RestApiClientServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RestApiClientService restApiClientService;

    @Test
    public void testSendToApi() {
        // Mocking dependencies
        String apiUrl = "http://example.com/api";
        when(restTemplate.postForObject(eq(apiUrl), any(HttpEntity.class), eq(String.class))).thenReturn("Success");

        // Create a sample Customer object
        Customer customer = new Customer();
        customer.setCustomerRef("123");
        customer.setCustomerName("John Doe");

        // Perform the test
        restApiClientService.sendToApi(customer);

        // Assertions
        HttpHeaders expectedHeaders = new HttpHeaders();
        expectedHeaders.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Customer> expectedRequestEntity = new HttpEntity<>(customer, expectedHeaders);

        verify(restTemplate, times(1)).postForObject(eq(apiUrl), eq(expectedRequestEntity), eq(String.class));
    }
}
