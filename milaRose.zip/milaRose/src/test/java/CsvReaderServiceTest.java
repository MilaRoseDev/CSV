import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
public class CsvReaderServiceTest {

    @Mock
    private CSVReaderBuilder csvReaderBuilder;

    @InjectMocks
    private CsvReaderService csvReaderService;

    @Test
    public void testReadCsvFileWithValidRows() throws IOException, CsvValidationException {
        // Mocking dependencies
        InputStream inputStream = new ClassPathResource("valid-test.csv").getInputStream();
        CSVReader csvReaderMock = Mockito.mock(CSVReader.class);
        Mockito.when(csvReaderBuilder.build()).thenReturn(csvReaderMock);

        // Mocking CSV data
        String[] validRow = {"1", "John Doe", "123 Street", "Apt 45", "City", "County", "Country", "12345"};
        Mockito.when(csvReaderMock.readNext()).thenReturn(validRow, null);

        // Perform the test
        List<Customer> customers = csvReaderService.readCsvFile(inputStream);

        // Assertions
        assertEquals(1, customers.size());
        assertEquals("John Doe", customers.get(0).getCustomerName());
    }

    @Test
    public void testReadCsvFileWithInvalidRow() throws IOException, CsvValidationException {
        // Mocking dependencies
        InputStream inputStream = new ClassPathResource("invalid-test.csv").getInputStream();
        CSVReader csvReaderMock = Mockito.mock(CSVReader.class);
        Mockito.when(csvReaderBuilder.build()).thenReturn(csvReaderMock);

        // Mocking CSV data
        String[] invalidRow = {"1", "John Doe", "123 Street", "Apt 45", "City", "County", "Country"};
        Mockito.when(csvReaderMock.readNext()).thenReturn(invalidRow, null);

        // Perform the test and assert the exception
        assertThrows(RuntimeException.class, () -> csvReaderService.readCsvFile(inputStream));
    }

    @Test
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }
}
