import com.opencsv.exceptions.CsvValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class CustomerControllerTest {

    @Mock
    private CsvReaderService csvReaderService;

    @Mock
    private RestApiClientService restApiClientService;

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testImportCustomers() throws IOException, CsvValidationException {
        // Mocking dependencies
        MultipartFile file = mock(MultipartFile.class);
        InputStream inputStream = mock(InputStream.class);
        when(file.getInputStream()).thenReturn(inputStream);

        List<Customer> customers = new ArrayList<>();
        when(csvReaderService.readCsvFile(inputStream)).thenReturn(customers);

        // Perform the test
        ResponseEntity<String> response = customerController.importCustomers(file);

        // Assertions
        assertEquals(ResponseEntity.ok("Customers imported successfully"), response);
        verify(customerService, times(1)).saveAll(customers);
    }

    @Test
    public void testImportCustomersWithError() throws IOException, CsvValidationException {
        // Mocking dependencies to simulate an error during import
        MultipartFile file = mock(MultipartFile.class);
        InputStream inputStream = mock(InputStream.class);
        when(file.getInputStream()).thenReturn(inputStream);
        when(csvReaderService.readCsvFile(inputStream)).thenThrow(new IOException("Error during import"));

        // Perform the test
        ResponseEntity<String> response = customerController.importCustomers(file);

        // Assertions
        assertEquals(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error importing customers"), response);
        verify(customerService, never()).saveAll(anyList());
    }

    @Test
    public void testGetCustomerByRef() {
        // Mocking dependencies
        String customerRef = "123";
        Customer expectedCustomer = new Customer();
        when(customerService.getByCustomerRef(customerRef)).thenReturn(expectedCustomer);

        // Perform the test
        ResponseEntity<Customer> response = customerController.getCustomerByRef(customerRef);

        // Assertions
        assertEquals(ResponseEntity.ok(expectedCustomer), response);
    }

    @Test
    public void testGetCustomerByRefNotFound() {
        // Mocking dependencies for a scenario where customer is not found
        String customerRef = "456";
        when(customerService.getByCustomerRef(customerRef)).thenReturn(null);

        // Perform the test
        ResponseEntity<Customer> response = customerController.getCustomerByRef(customerRef);

        // Assertions
        assertEquals(ResponseEntity.notFound().build(), response);
    }

    @Test
    public void testGetCustomerByRefWithError() {
        // Mocking dependencies to simulate an error during retrieval
        String customerRef = "789";
        when(customerService.getByCustomerRef(customerRef)).thenThrow(new RuntimeException("Error during retrieval"));

        // Perform the test
        ResponseEntity<Customer> response = customerController.getCustomerByRef(customerRef);

        // Assertions
        assertEquals(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null), response);
    }
}
