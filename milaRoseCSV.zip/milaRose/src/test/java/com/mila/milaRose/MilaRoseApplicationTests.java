package com.mila.milaRose;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MilaRoseApplicationTests {

	@Test
	void contextLoads() {
	}

}
