import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    @Test
    public void testGetByCustomerRef() {
        // Mocking dependencies
        String customerRef = "123";
        Customer expectedCustomer = new Customer();
        when(customerRepository.findByCustomerRef(customerRef)).thenReturn(expectedCustomer);

        // Perform the test
        Customer result = customerService.getByCustomerRef(customerRef);

        // Assertions
        assertEquals(expectedCustomer, result);
        verify(customerRepository, times(1)).findByCustomerRef(customerRef);
    }

    @Test
    public void testSaveAll() {
        // Mocking dependencies
        List<Customer> customersToSave = Arrays.asList(new Customer(), new Customer());

        // Perform the test
        customerService.saveAll(customersToSave);

        // Assertions
        verify(customerRepository, times(1)).saveAll(customersToSave);
    }

}
