import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerTest {

    @Test
    public void testGettersAndSetters() {
        // Create a Customer object
        Customer customer = new Customer();

        // Set values using setters
        customer.setCustomerRef("123");
        customer.setCustomerName("John Doe");
        customer.setAddressLine1("123 Street");
        customer.setAddressLine2("Apt 45");
        customer.setTown("City");
        customer.setCounty("County");
        customer.setCountry("Country");
        customer.setPostcode("12345");

        // Verify values using getters
        assertEquals("123", customer.getCustomerRef());
        assertEquals("John Doe", customer.getCustomerName());
        assertEquals("123 Street", customer.getAddressLine1());
        assertEquals("Apt 45", customer.getAddressLine2());
        assertEquals("City", customer.getTown());
        assertEquals("County", customer.getCounty());
        assertEquals("Country", customer.getCountry());
        assertEquals("12345", customer.getPostcode());
    }
}
