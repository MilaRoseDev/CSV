import org.springframework.data.jpa.repository.JpaRepository;
// CustomerRepository.java
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Customer findByCustomerRef(String customerRef);
}
